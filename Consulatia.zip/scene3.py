import time
from dialoguePackage import aDialogue
t = 4
#  THIS FILE IS A WORK IN PROGRESS

#  this is the library scene
# --------------------------------------------------------------------------------------------------------------------
def les_team_book():
    print("Les's party who defeated the first Demon Lord consisted of Les, Essie and Kexus")
    time.sleep(t)
    print("Les started out as a simple adventurer, who found both Essie and Kexus at the adventurers guild hall")
    time.sleep(t)
    print("This group gained much notablityy for their fast work of quests and their ability to handle such high level tasks with incredible skill")
    time.sleep(t)
    print("When the demon lord struck, Les's party rose to the challenge to fight the Demon Lord")
    time.sleep(t)
    print("Les and his party managed to convince the humans to create an alliance, and they lead this alliance to war")
    time.sleep(t)
    print("During this great battle Les was able to defeat the Demon Lord")
    time.sleep(t)
    print("While it is not known how or why Les rose to Atherial at the end of the Battle, he did")
    time.sleep(t)
    print("Les's party disbanded with Kexus and Essie heading their own seperate ways")
    time.sleep(t)
    print("Kexus went to the city of Frostfall, where he built his wizards tower and began creating his library of knowledge")
    time.sleep(t)
    print("Not much is known about the whereabouts of Essie, but it is say she can most likely be found at an inn with a bottle of mead")
    time.sleep(t)

# -------------------------------------------------------------------------------------------------------------------
def god_book():
    print("Us humans currently know two different types of gods that interact with us")
    time.sleep(t)
    print("They are the Atherial, and the Dratherial")
    time.sleep(t)
    print('The Atherial are gods who are considered to be "good" or "neutral" whereas the Dratherial are considered to be "bad"')
    time.sleep(t)
    print("The Atherial currently consists of [PLACEHOLDER LIST OF NAMES]")
    time.sleep(t)
    print("The Dratherial currently consists of [PLACEHOLDER LIST OF NAMES]")
    time.sleep(t)
    print("The Atherial have been know to take actions that benefit mankind, and in one rare case a human became an Atherial")
    time.sleep(t)
    print("This humans name was Les, and they now live in the same plane of existence as the Atherial.")
    time.sleep(t)
    print("Les being the hero of mankind from before, is worshiped as a protector of humanity and a savior of mankind")
    time.sleep(t)
    print("The Dratherial have constantly sought to takeout mankind and allow their monstrous creations to run wild.")
    time.sleep(t)
    print("They once attempted to appoint a human as a champion and leader of their monster forces, who became the first Demon Lord")
    time.sleep(t)
    print("The Atherial are also have chosen champions before, most notably Les who rose to become an Atherial himself")
    time.sleep(t)

# --------------------------------------------------------------------------------------------------------------------
def history_book():
    print("At the beginning of time the gods made humankind, and monsters")
    time.sleep(t)
    print("The world had heros who protected everyone from the monsters that inhabited the land, but some didn’t wish to help mankind and instead wished to destroy it.")
    time.sleep(t)
    print("One man learned dark magics from the Dratherial that allowed him to control the monsters and give them intelligence.")
    time.sleep(t)
    print("His name was Dregroth, and he became the first Demon Lord.")
    time.sleep(t)
    print("His power was unmatched, and he began to attempt to wipe out any who opposed him and his ultimate rule of the world.")
    time.sleep(t)
    print("A group of heroes rose to the challenge of Dregoth, blessed by the Atherial to take him down.")
    time.sleep(t)
    print("The group member’s names were Les, Essie and Kexus.")
    time.sleep(t)
    print("They led a massive army to fight the Demon Lord’s forces which sparked the Great War.")
    time.sleep(t)
    print("This war ended with  Les’s team defeating Dregroth, and Les’s ascension to Atherial.")


# ---------------------------------------------------------------------------------------------------------------------
def scene3():
    print("Kexus leads you through the debris in the town to a tall tower which is seems to have taken no damage in the battle")
    time.sleep(t)
    print("You follow him as he leads you inside, as you walk he begins to explain")
    time.sleep(t)
    print('Kexus: "This is my tower, where I work endlessly day and night, I placed a magical barrier around the tower'
          "\n" "as soon as I saw the Demon Lords army approaching")
    time.sleep(t)
    print('Kexus: "Inside I have many books with knowledge that you might find helpful on your journey"')
    time.sleep(t)
    print('You continue to follow Kexus up the winding stairs until you get to the top of the tower where there is a giant room full of books')
    time.sleep(t)
    print('Kexus points to a chair nearby and motions for you to have a seat')
    time.sleep(t)
    print('Kexus: "Sit tight, let me find a book you may find helpful"')
    time.sleep(t)
    print('Kexus hands you a book titled "A Brief History of Consulatia"')
    time.sleep(t)
    print('You open the book and begin to read')
    time.sleep(t)

    history_book()
    time.sleep(t)

    print('Kexus: "You may also find this book helpful"')
    time.sleep(t)
    print('Kexus hands you another book, this one titled "The Atherial and Dratherial"')
    time.sleep(t)

    god_book()
    time.sleep(t)

    aDialogue.getTree('library').callAnswer()




    #  at the end of talking to Kexus, he hands you les's first sword, which will append the steel sword

#  scene3()