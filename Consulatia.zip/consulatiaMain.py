from scene1 import scene1
from scene2 import scene2
from scene3 import scene3


def main():
    scene1()
    scene2()
    scene3()
    print("*END OF DEMO*")

main()
